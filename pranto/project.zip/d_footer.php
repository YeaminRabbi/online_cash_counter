<footer class="sl-footer">
    <div class="footer-left">
      <div class="mg-b-2">Copyright &copy; 2021-2030. Online Cash Counter. All Rights Reserved.</div>
      <div>Developed by Pranto & Apu</div>
    </div>
</footer>